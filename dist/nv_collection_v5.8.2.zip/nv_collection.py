"""A project collection manager plugin for novelibre.

Requires Python 3.7+
Copyright (c) Peter Triesberger
For further information see https://github.com/peter88213/nv_collection
License: GNU GPLv3 (https://www.gnu.org/licenses/gpl-3.0.en.html)

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
"""
import gettext
import locale
import os
import sys

LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
try:
    CURRENT_LANGUAGE = locale.getlocale()[0][:2]
except:
    CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
try:
    t = gettext.translation(
        'nv_collection',
        LOCALE_PATH,
        languages=[CURRENT_LANGUAGE],
    )
    _ = t.gettext
except:

    def _(message):
        return message


FEATURE = _('Collection')
SERIES_PREFIX = 'sr'
BOOK_PREFIX = 'bk'
HELP_PAGE = 'nv_collection'
from abc import ABC, abstractmethod
from pathlib import Path



class SubController:

    def disable_menu(self):
        pass

    def enable_menu(self):
        pass

    def lock(self):
        pass

    def on_close(self):
        pass

    def on_open(self):
        pass

    def on_quit(self):
        pass

    def unlock(self):
        pass

import tkinter as tk


class PluginBase(ABC, SubController):
    VERSION = ''
    API_VERSION = ''
    DESCRIPTION = ''
    URL = ''
    HELP_SITE = None
    HELP_PAGE = None

    def __init__(self):
        self.filePath = None
        self.isActive = True
        self.isRejected = False

        self._icon = None

    @abstractmethod
    def install(self, model, view, controller):
        self._mdl = model
        self._ui = view
        self._ctrl = controller

    def uninstall(self):
        pass

    def _add_help_menu_entry(self, label):

        def open_help():
            self._ctrl.helpService.open_help_page(
                self.HELP_PAGE,
                site=self.HELP_SITE
            )

        self._ui.helpMenu.add_command(
            label=label,
            image=self._icon,
            compound='left',
            command=open_help,
        )

    def _get_icon(self, fileName):
        if self._ctrl.get_preferences().get('large_icons', False):
            size = 24
        else:
            size = 16
        try:
            homeDir = str(Path.home()).replace('\\', '/')
            iconPath = f'{homeDir}/.novx/icons/{size}'
            icon = tk.PhotoImage(file=f'{iconPath}/{fileName}')
        except:
            icon = None
        return icon
from pathlib import Path

from tkinter import filedialog
from tkinter import ttk




class Book:

    def __init__(self, filePath):
        self.filePath = filePath
        self.title = None
        self.desc = None

    def pull_metadata(self, novel):
        modified = False
        if self.title != novel.title:
            self.title = novel.title
            modified = True
        if self.desc != novel.desc:
            self.desc = novel.desc
            modified = True
        return modified

    def push_metadata(self, novel):
        novel.title = self.title
        novel.desc = self.desc



try:
    LOCALE_PATH
except NameError:
    locale.setlocale(locale.LC_TIME, "")
    LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
    try:
        CURRENT_LANGUAGE = locale.getlocale()[0][:2]
    except:
        CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
    try:
        t = gettext.translation(
            'novelibre',
            LOCALE_PATH,
            languages=[CURRENT_LANGUAGE],
        )
        _ = t.gettext
    except:

        def _(message):
            return message


ROOT_PREFIX = 'rt'
CHAPTER_PREFIX = 'ch'
PLOT_LINE_PREFIX = 'ac'
SECTION_PREFIX = 'sc'
PLOT_POINT_PREFIX = 'ap'
CHARACTER_PREFIX = 'cr'
LOCATION_PREFIX = 'lc'
ITEM_PREFIX = 'it'
PRJ_NOTE_PREFIX = 'pn'
CH_ROOT = f'{ROOT_PREFIX}{CHAPTER_PREFIX}'
PL_ROOT = f'{ROOT_PREFIX}{PLOT_LINE_PREFIX}'
CR_ROOT = f'{ROOT_PREFIX}{CHARACTER_PREFIX}'
LC_ROOT = f'{ROOT_PREFIX}{LOCATION_PREFIX}'
IT_ROOT = f'{ROOT_PREFIX}{ITEM_PREFIX}'
PN_ROOT = f'{ROOT_PREFIX}{PRJ_NOTE_PREFIX}'

BRF_SYNOPSIS_SUFFIX = '_brf_synopsis'
CHAPTERLIST_SUFFIX = '_chapterlist_tmp'
CHAPTERS_SUFFIX = '_chapters_tmp'
CHAPTER_BOARD_SUFFFIX = '_sectioncards'
CHARACTERS_SUFFIX = '_characters_tmp'
CHARACTER_REPORT_SUFFIX = '_character_report'
CHARLIST_SUFFIX = '_charlist_tmp'
DATA_SUFFIX = '_data'
ELEMENT_NOTES_SUFFIX = '_element_note_report',
FULL_MANUSCRIPT_SUFFIX = '_full_tmp'
GRID_REPORT_SUFFIX = '_grid_report'
GRID_SUFFIX = '_grid_tmp'
ITEMLIST_SUFFIX = '_itemlist_tmp'
ITEMS_SUFFIX = '_items_tmp'
ITEM_REPORT_SUFFIX = '_item_report'
LOCATIONS_SUFFIX = '_locations_tmp'
LOCATION_REPORT_SUFFIX = '_location_report'
LOCLIST_SUFFIX = '_loclist_tmp'
MANUSCRIPT_SUFFIX = '_manuscript_tmp'
METADATA_TEXT_SUFFIX = '_metadata_text_tmp'
MINOR_MARKER = _('Minor Character')
PARTLIST_SUFFIX = '_partlist_tmp'
PARTS_SUFFIX = '_parts_tmp'
PLOTLINES_SUFFIX = '_plotlines_tmp'
PLOTLIST_SUFFIX = '_plotlist'
PLOT_LINE_BOARD_SUFFIX = '_plotcards'
PROJECTNOTES_REPORT_SUFFIX = '_projectnotes_report'
PROJECTNOTES_SUFFIX = '_projectnotes_tmp'
PROOF_SUFFIX = '_proof_tmp'
SECTIONLIST_SUFFIX = '_sectionlist'
SECTIONS_SUFFIX = '_sections_tmp'
STAGES_SUFFIX = '_structure_tmp'
STORY_STRUCT_BOARD_SUFFIX = '_stagecards'
TIMETABLE_SUFFIX = '_tt_tmp'
VIEWPOINT_BOARD_SUFFFIX = '_viewpoint_board'
XREF_SUFFIX = '_xref'

MAJOR_MARKER = _('Major Character')

NO_SCENE_FIELD_1_DEFAULT = _('Plot progress')
NO_SCENE_FIELD_2_DEFAULT = _('Characterization')
NO_SCENE_FIELD_3_DEFAULT = _('World building')
OTHER_SCENE_FIELD_1_DEFAULT = _('Opening')
OTHER_SCENE_FIELD_2_DEFAULT = _('Peak emotional moment')
OTHER_SCENE_FIELD_3_DEFAULT = _('Ending')
CR_FIELD_1_DEFAULT = _('Bio')
CR_FIELD_2_DEFAULT = _('Goals')

STATUS = [
    None,
    _('Outline'),
    _('Draft'),
    _('1st Edit'),
    _('2nd Edit'),
    _('Done')
]

SCENE = ['-', 'A', 'R', 'x']


def norm_path(path):
    if path is None:
        path = ''
    return os.path.normpath(path)


def string_to_list(text, divider=';'):
    elements = []
    try:
        tempList = text.split(divider)
        for element in tempList:
            element = element.strip()
            if element and not element in elements:
                elements.append(element)
        return elements

    except:
        return []


def list_to_string(elements, divider=';'):
    try:
        return divider.join(elements)

    except:
        return ''


def intersection(elemList, refList):
    return [elem for elem in elemList if elem in refList]


def verified_int_string(intStr):
    if intStr is not None:
        int(intStr)
    return intStr

import xml.etree.ElementTree as ET


class NvcxOpener:

    @classmethod
    def get_xml_root(cls, filePath, majorVersion, minorVersion):
        try:
            xmlTree = ET.parse(filePath)
        except Exception as ex:
            raise RuntimeError(
                f'{_("Cannot process file")}: '
                f'"{norm_path(filePath)}" - {str(ex)}'
            )

        xmlRoot = xmlTree.getroot()
        if not xmlRoot.tag in ('nvcx', 'COLLECTION'):
            msg = _("No valid xml root element found in file")
            raise RuntimeError(f'{msg}: "{norm_path(filePath)}".')

        fileMajorVersion, fileMinorVersion = cls._get_file_version(
            xmlRoot,
            filePath,
        )
        fileMajorVersion, fileMinorVersion = cls._upgrade_file_version(
            xmlRoot,
            fileMajorVersion,
            fileMinorVersion,
        )
        cls._check_version(
            fileMajorVersion,
            fileMinorVersion,
            filePath,
            majorVersion,
            minorVersion,
        )
        return xmlRoot

    @classmethod
    def _check_version(
            cls,
            fileMajorVersion,
            fileMinorVersion,
            filePath,
            majorVersion,
            minorVersion,
    ):
        if fileMajorVersion > majorVersion:
            msg = _('The collection "{}" was created with a newer plugin version.')
            raise RuntimeError(msg.format(norm_path(filePath)))

        if fileMajorVersion < majorVersion:
            msg = _('The collection "{}" was created with an outdated plugin version.')
            raise RuntimeError(msg.format(norm_path(filePath)))

        if fileMinorVersion > minorVersion:
            msg = _('The collection "{}" was created with a newer plugin version.')
            raise RuntimeError(msg.format(norm_path(filePath)))

    @classmethod
    def _upgrade_file_version(
            cls,
            xmlRoot,
            fileMajorVersion,
            fileMinorVersion,
    ):
        return fileMajorVersion, fileMinorVersion

    @classmethod
    def _get_file_version(cls, xmlRoot, filePath):
        try:
            (
                fileMajorVersionStr,
                fileMinorVersionStr
            ) = xmlRoot.attrib['version'].split('.')
            fileMajorVersion = int(fileMajorVersionStr)
            fileMinorVersion = int(fileMinorVersionStr)
        except (KeyError, ValueError):
            msg = _("No valid version found in file")
            raise RuntimeError(msg.format(norm_path(filePath)))

        return fileMajorVersion, fileMinorVersion



class Series:

    def __init__(self):
        self.title = None
        self.desc = None


def new_id(elements, prefix=''):
    i = 1
    while f'{prefix}{i}' in elements:
        i += 1
    return f'{prefix}{i}'

import re


def strip_illegal_characters(text):
    return re.sub('[\x00-\x08|\x0b-\x0c|\x0e-\x1f]', '', text)



def indent(elem, level=0):
    PARAGRAPH_LEVEL = 5

    i = f'\n{level * "  "}'
    if len(elem):
        if not elem.text or not elem.text.strip():
            elem.text = f'{i}  '
        if not elem.tail or not elem.tail.strip():
            elem.tail = i
        if level < PARAGRAPH_LEVEL:
            for elem in elem:
                indent(elem, level + 1)
        if not elem.tail or not elem.tail.strip():
            elem.tail = i
    else:
        if level and (not elem.tail or not elem.tail.strip()):
            elem.tail = i
import tkinter.font as tkFont


class Collection:
    MAJOR_VERSION = 1
    MINOR_VERSION = 1

    EXTENSION = 'nvcx'

    XML_HEADER = (
        '<?xml version="1.0" encoding="utf-8"?>\n'
        f'<!DOCTYPE nvcx SYSTEM "nvcx_{MAJOR_VERSION}_{MINOR_VERSION}.dtd">\n'
    )
    fileOpener = NvcxOpener

    def __init__(self, filePath, tree):
        self.title = None
        self.tree = tree
        fontSize = tkFont.nametofont('TkDefaultFont').actual()['size']
        self.tree.tag_configure('SERIES', font=('', fontSize, 'bold'))

        self.books = {}

        self.series = {}

        self._filePath = None

        self.filePath = filePath

    @property
    def filePath(self):
        return self._filePath

    @filePath.setter
    def filePath(self, filePath):
        if filePath.lower().endswith(self.EXTENSION):
            self._filePath = filePath
            self.title, __ = os.path.splitext(os.path.basename(self.filePath))

    def add_book(self, book, parent='', index='end'):
        if book.filePath is None:
            raise RuntimeError(
                _('There is no file for the current project. Please save first.')
            )

        if not os.path.isfile(book.filePath):
            raise RuntimeError(f'"{norm_path(book.filePath)}" not found.')

        for bkId in self.books:
            if book.filePath == self.books[bkId].filePath:
                return None

        bkId = new_id(self.books, prefix=BOOK_PREFIX)
        self.books[bkId] = Book(book.filePath)
        self.books[bkId].pull_metadata(book.novel)
        self.tree.insert(
            parent,
            index,
            bkId,
            text=self.books[bkId].title,
            open=True,
        )
        return bkId

    def add_series(self, seriesTitle, index='end'):
        srId = new_id(self.series, prefix=SERIES_PREFIX)
        self.series[srId] = Series()
        self.series[srId].title = seriesTitle
        self.tree.insert(
            '',
            index,
            srId,
            text=self.series[srId].title,
            tags='SERIES',
            open=True,
        )
        return srId

    def read(self):

        def get_book(parent, xmlBook):
            bkId = xmlBook.attrib[('id')]
            xmlPath = xmlBook.find('Path')
            if xmlPath is not None:
                bookPath = xmlPath.text
                if bookPath and os.path.isfile(bookPath):
                    self.books[bkId] = Book(bookPath)
                    xmlTitle = xmlBook.find('Title')
                    if xmlTitle is not None and xmlTitle.text:
                        self.books[bkId].title = xmlTitle.text
                    else:
                        self.books[bkId].title = f"{_('Untitled')} ({bkId})"
                    xmlDesc = xmlBook.find('Desc')
                    if xmlDesc is not None:
                        paragraphs = []
                        for xmlParagraph in xmlDesc.iterfind('p'):
                            if xmlParagraph.text:
                                paragraphs.append(xmlParagraph.text)
                        self.books[bkId].desc = '\n'.join(paragraphs)
                    self.tree.insert(
                        parent,
                        'end',
                        bkId,
                        text=self.books[bkId].title,
                        open=True,
                    )

        xmlRoot = self.fileOpener.get_xml_root(
            self.filePath,
            self.MAJOR_VERSION,
            self.MINOR_VERSION,
        )
        self.reset_tree()
        self.books.clear()
        self.series.clear()
        for xmlElement in xmlRoot:
            if xmlElement.tag == 'BOOK':
                get_book('', xmlElement)
            elif xmlElement.tag == 'SERIES':
                srId = xmlElement.attrib['id']
                self.series[srId] = Series()
                xmlTitle = xmlElement.find('Title')
                if xmlTitle is not None and xmlTitle.text:
                    self.series[srId].title = xmlTitle.text
                else:
                    self.series[srId].title = f"{_('Untitled')} ({srId})"
                xmlDesc = xmlElement.find('Desc')
                if xmlDesc is not None:
                    paragraphs = []
                    for xmlParagraph in xmlDesc.iterfind('p'):
                        if xmlParagraph.text:
                            paragraphs.append(xmlParagraph.text)
                    self.series[srId].desc = '\n'.join(paragraphs)
                self.tree.insert(
                    '',
                    'end',
                    srId,
                    text=self.series[srId].title,
                    tags='SERIES',
                    open=True,
                )
                for xmlBook in xmlElement.iter('BOOK'):
                    get_book(srId, xmlBook)
        if not xmlRoot.attrib.get('version', None):
            self.write()
        return (
            f'{len(self.books)} Books found '
            f'in "{norm_path(self.filePath)}".'
        )

    def remove_book(self, bkId):
        bookTitle = bkId
        try:
            bookTitle = self.books[bkId].title
            del self.books[bkId]
            self.tree.delete(bkId)
            message = (
                f'{_("Book removed from the collection")}: '
                f'"{bookTitle}".'
            )
            return message
        except:
            raise RuntimeError(f'{_("Cannot remove book")}: "{bookTitle}".')

    def remove_series(self, srId):
        seriesTitle = self.series[srId].title
        for bookNode in self.tree.get_children(srId):
            self.tree.move(bookNode, '', 'end')
        del(self.series[srId])
        self.tree.delete(srId)
        return f'{_("Series removed from the collection")}: "{seriesTitle}".'

        raise RuntimeError(f'{_("Cannot remove series")}: "{seriesTitle}".')

    def remove_series_with_books(self, srId):
        seriesTitle = self.series[srId].title
        for bkId in self.tree.get_children(srId):
            del self.books[bkId]
        del(self.series[srId])
        self.tree.delete(srId)
        return f'{_("Series removed from the collection")}: "{seriesTitle}".'

        raise RuntimeError(f'{_("Cannot remove series")}: "{seriesTitle}".')

    def reset_tree(self):
        for child in self.tree.get_children(''):
            self.tree.delete(child)

    def write(self):

        def walk_tree(node, xmlNode):
            for elementId in self.tree.get_children(node):
                if elementId.startswith(BOOK_PREFIX):
                    xmlBook = ET.SubElement(xmlNode, 'BOOK')
                    xmlBook.set('id', elementId)
                    xmlBookTitle = ET.SubElement(xmlBook, 'Title')
                    if self.books[elementId].title:
                        xmlBookTitle.text = self.books[elementId].title
                    if self.books[elementId].desc:
                        xmlBookDesc = ET.SubElement(xmlBook, 'Desc')
                        for paragraph in self.books[
                            elementId
                        ].desc.split('\n'):
                            ET.SubElement(
                                xmlBookDesc,
                                'p',
                            ).text = paragraph.strip()
                    xmlBookPath = ET.SubElement(xmlBook, 'Path')
                    xmlBookPath.text = self.books[elementId].filePath
                elif elementId.startswith(SERIES_PREFIX):
                    xmlSeries = ET.SubElement(xmlNode, 'SERIES')
                    xmlSeries.set('id', elementId)
                    xmlSeriesTitle = ET.SubElement(xmlSeries, 'Title')
                    if self.series[elementId].title:
                        xmlSeriesTitle.text = self.series[elementId].title
                    if self.series[elementId].desc:
                        xmlSeriesDesc = ET.SubElement(xmlSeries, 'Desc')
                        for paragraph in self.series[elementId
                                                     ].desc.split('\n'):
                            ET.SubElement(
                                xmlSeriesDesc,
                                'p',
                            ).text = paragraph.strip()
                    walk_tree(elementId, xmlSeries)

        xmlRoot = ET.Element('nvcx')
        xmlRoot.set('version', f'{self.MAJOR_VERSION}.{self.MINOR_VERSION}')
        walk_tree('', xmlRoot)

        indent(xmlRoot)
        xmlTree = ET.ElementTree(xmlRoot)
        backedUp = False
        if os.path.isfile(self.filePath):
            try:
                os.replace(self.filePath, f'{self.filePath}.bak')
            except:
                raise RuntimeError(
                    f'{_("Cannot overwrite file")}: '
                    f'"{norm_path(self.filePath)}".'
                )
            else:
                backedUp = True
        try:
            xmlTree.write(self.filePath, encoding='utf-8')

            self._postprocess_xml_file(self.filePath)
        except:
            if backedUp:
                os.replace(f'{self.filePath}.bak', self.filePath)
            raise RuntimeError(
                f'{_("Cannot write file")}: '
                f'"{norm_path(self.filePath)}".'
            )

        return f'"{norm_path(self.filePath)}" written.'

    def _postprocess_xml_file(self, filePath):
        with open(filePath, 'r', encoding='utf-8') as f:
            text = f.read()
            text = strip_illegal_characters(text)
        try:
            with open(filePath, 'w', encoding='utf-8') as f:
                f.write(f'{self.XML_HEADER}{text}')
        except:
            raise RuntimeError(f'{_("Cannot write file")}: "{norm_path(filePath)}".')

import platform



class GenericKeys:

    OPEN_HELP = ('<F1>', 'F1')
    QUIT_PROGRAM = ('<Control-q>', f'{_("Ctrl")}-Q')



class GenericMouse:

    LEFT_CLICK = '<Button-1>'
    MOVE_NODE = '<B1-Motion>'


class MacKeys(GenericKeys):

    QUIT_PROGRAM = ('<Command-q>', 'Cmd-Q')


class WindowsKeys(GenericKeys):

    QUIT_PROGRAM = ('<Alt-F4>', 'Alt-F4')

MOUSE = GenericMouse
if platform.system() == 'Windows':
    PLATFORM = 'win'
    KEYS = WindowsKeys()
elif platform.system() in ('Linux', 'FreeBSD'):
    PLATFORM = 'ix'
    KEYS = GenericKeys()
elif platform.system() == 'Darwin':
    PLATFORM = 'mac'
    KEYS = MacKeys()
else:
    PLATFORM = ''
    KEYS = GenericKeys()

from tkinter import ttk



class TextBox(tk.Text):

    def __init__(self, master=None, scrollbar=True, **kw):
        if kw.get('font', None) is None:
            kw['font'] = 'Courier 10'
        if scrollbar:
            self.frame = ttk.Frame(master)
            self.vbar = ttk.Scrollbar(self.frame)
            self.vbar.pack(side='right', fill='y')

            kw.update({'yscrollcommand': self.vbar.set})
            tk.Text.__init__(self, self.frame, **kw)
            self.pack(side='left', fill='both', expand=True)
            self.vbar['command'] = self.yview

            text_meths = vars(tk.Text).keys()
            methods = (
                vars(tk.Pack).keys()
                | vars(tk.Grid).keys()
                | vars(tk.Place).keys()
            )
            methods = methods.difference(text_meths)

            for m in methods:
                if m[0] != '_' and m != 'config' and m != 'configure':
                    setattr(self, m, getattr(self.frame, m))
        else:
            tk.Text.__init__(self, master, **kw)

        self.hasChanged = False
        self.bind('<KeyRelease>', self._on_edit)

    def clear(self):
        self.delete('1.0', 'end')
        self.hasChanged = False

    def get_text(self):
        text = self.get('1.0', 'end').strip(' \n')
        return text

    def set_text(self, text):
        self.clear()
        if text:
            self.insert('end', text)
            self.edit_reset()

    def _on_edit(self, event=None):
        self.hasChanged = True



class MyStringVar(tk.StringVar):

    def set(self, value):
        if value is None:
            value = ''
        super().set(value)

    def get(self, default=None):
        value = super().get()
        if value == '':
            value = default
            if default is not None:
                self.set(default)
        return value


class IndexCard(tk.Frame):

    def __init__(
            self,
            master=None,
            cnf={},
            fg='black',
            bg='white',
            font=None,
            scrollbar=True,
            **kw
    ):
        super().__init__(master=master, cnf=cnf, **kw)
        self._bgColor = bg

        titleFrame = tk.Frame(
            self,
            background=bg,
        )
        titleFrame.pack(
            fill='x',
        )
        self.colorField = tk.Label(
            titleFrame,
            width=2,
            background=bg,
        )
        self.colorField.pack(
            side='right',
            expand=False,
        )
        self.title = MyStringVar(value='')
        self.titleEntry = tk.Entry(
            titleFrame,
            bg=bg,
            bd=0,
            textvariable=self.title,
            relief='flat',
            font=font,
            background=bg,
            foreground=fg,
            insertbackground=fg,
        )
        self.titleEntry.pack(
            side='left',
            ipady=6,
            fill='x',
            expand=True,
        )

        tk.Frame(self, bg='red', height=1, bd=0).pack(fill='x')
        tk.Frame(self, bg=bg, height=1, bd=0).pack(fill='x')

        self.bodyBox = TextBox(
            self,
            scrollbar=scrollbar,
            wrap='word',
            undo=True,
            autoseparators=True,
            maxundo=-1,
            padx=5,
            pady=5,
            bg=bg,
            fg=fg,
            insertbackground=fg,
            font=font,
        )
        self.bodyBox.pack(fill='both', expand=True)

    def lock(self):
        self.titleEntry.config(state='disabled')
        self.bodyBox.config(state='disabled')

    def reset_color(self):
        self.colorField.configure(
            bg=self._bgColor,
            text='◈',
        )

    def set_color(self, color):
        self.colorField.configure(
            bg=color,
            text='',
        )

    def unlock(self):
        self.titleEntry.config(state='normal')
        self.bodyBox.config(state='normal')


class CollectionView(tk.Toplevel, SubController):
    HEIGHT_BIAS = 20

    def __init__(self, model, view, controller, prefs):
        super().__init__()
        self._mdl = model
        self._ui = view
        self._ctrl = controller
        self.prefs = prefs
        self.isModified = False
        self.element = None
        self.nodeId = None
        self.geometry(self.prefs['window_geometry'])
        self.update_idletasks()

        self.title(FEATURE)
        self.statusText = ''

        self.lift()
        self.focus()

        self._mainMenu = tk.Menu(self)
        self.config(menu=self._mainMenu)

        self._pathBar = tk.Label(
            self,
            text='',
            anchor='w',
            padx=5,
            pady=3,
        )
        self._pathBar.pack(expand=False, fill='both', side='bottom')

        self._statusBar = tk.Label(
            self,
            text='',
            anchor='w',
            padx=5,
            pady=2,
        )
        self._statusBar.pack(expand=False, fill='both', side='bottom')
        self._statusBar.bind(MOUSE.LEFT_CLICK, self._restore_status)

        self._mainWindow = ttk.Frame(self)
        self._mainWindow.pack(
            fill='both',
            padx=2,
            pady=2,
            expand=True,
        )

        self._collection = None

        self._treeView = ttk.Treeview(
            self._mainWindow,
            selectmode='browse',
        )
        scrollY = ttk.Scrollbar(
            self._treeView,
            orient='vertical',
            command=self._treeView.yview,
        )
        self._treeView.configure(yscrollcommand=scrollY.set)
        scrollY.pack(side='right', fill='y')
        self._treeView.pack(
            side='left',
            expand=True,
            fill='both',
        )
        self._treeView.bind('<<TreeviewSelect>>', self._on_select_node)
        self._treeView.bind('<Double-1>', self._open_book)
        self._treeView.bind('<Return>', self._open_book)
        self._treeView.bind('<Delete>', self._remove_node)
        self._treeView.bind('<Shift-Delete>', self._remove_series_with_books)
        self._treeView.bind(MOUSE.MOVE_NODE, self._move_node)

        self._indexCard = IndexCard(self._mainWindow,
            bd=2,
            relief='ridge',
            width=prefs['right_frame_width'],
            fg=prefs['color_text_fg'],
            bg=prefs['color_text_bg'],
        )
        self._indexCard.pack(
            side='right',
            expand=False,
            fill='both',
        )
        self._indexCard.pack_propagate(0)
        self._indexCard.titleEntry.bind('<Return>', self._apply_changes)
        self._indexCard.titleEntry.bind('<FocusOut>', self._apply_changes)

        self._fileMenu = tk.Menu(self._mainMenu, tearoff=0)
        self._mainMenu.add_cascade(
            label=_('File'),
            menu=self._fileMenu,
        )
        self._fileMenu.add_command(
            label=_('New'),
            command=self._create_new_collection,
        )
        self._fileMenu.add_command(
            label=_('Open...'),
            command=self._open_collection,
        )
        self._fileMenu.add_command(
            label=_('Save'),
            state='disabled',
            command=self._save_collection,
        )
        self._fileMenu.add_command(
            label=_('Close'),
            state='disabled',
            command=self._close_collection,
            )
        if PLATFORM == 'win':
            self._fileMenu.add_command(
                label=_('Exit'),
                accelerator=KEYS.QUIT_PROGRAM[1],
                command=self.on_quit,
            )
        else:
            self._fileMenu.add_command(
                label=_('Quit'),
                accelerator=KEYS.QUIT_PROGRAM[1],
                command=self.on_quit,
            )

        self._seriesMenu = tk.Menu(self._mainMenu, tearoff=0)
        self._mainMenu.add_cascade(
            label=_('Series'),
            menu=self._seriesMenu,
        )
        self._seriesMenu.add_command(
            label=_('Add'),
            command=self._add_series,
        )
        self._seriesMenu.add_command(
            label=_('Remove selected series but keep the books'),
            command=self._remove_series,
        )
        self._seriesMenu.add_command(
            label=_('Remove selected series and books'),
            command=self._remove_series_with_books,
        )

        self._bookMenu = tk.Menu(self._mainMenu, tearoff=0)
        self._mainMenu.add_cascade(
            label=_('Book'),
            menu=self._bookMenu,
        )
        self._bookMenu.add_command(
            label=_('Add current project to the collection'),
            command=self._add_current_project,
        )
        self._bookMenu.add_command(
            label=_('Remove selected book from the collection'),
            command=self._remove_book,
        )
        self._bookMenu.add_command(
            label=_('Update book data from the current project'),
            command=self._update_collection,
        )
        self._bookMenu.add_command(
            label=_('Update project data from the selected book'),
            command=self._update_project,
        )

        self._mainMenu.add_command(
            label=_('Help'),
            accelerator='F1',
            command=self._open_help,
        )

        self.protocol("WM_DELETE_WINDOW", self.on_quit)
        if PLATFORM != 'win':
            self.bind(KEYS.QUIT_PROGRAM[0], self.on_quit)
        self.bind(KEYS.OPEN_HELP[0], self._open_help)
        self.bind('<Escape>', self._restore_status)
        self._open_last_collection()

    def on_quit(self, event=None):
        self._apply_changes()
        self.update_idletasks()
        self.prefs['window_geometry'] = self.winfo_geometry()
        try:
            if self._collection is not None and self.isModified:
                if self._ui.ask_yes_no(
                    message=_('Save changes?'),
                    detail=_('There are unsaved changes'),
                    title=FEATURE,
                    parent=self,
                ):
                    self._save_collection()
        except Exception as ex:
            self._show_cannot_save_error(str(ex))
        finally:
            self.destroy()
            self.isOpen = False

    def _add_current_project(self, event=None):
        self._apply_changes()
        try:
            selection = self._collection.tree.selection()[0]
        except:
            selection = ''
        book = self._mdl.prjFile
        if not self._mdl.prjFile.novel.title:
            self._set_status(f'!{_("This project has no title")}.')
            return

        parent = ''
        if selection.startswith(BOOK_PREFIX):
            parent = self._collection.tree.parent(selection)
            index = self._collection.tree.index(selection) + 1
        elif selection.startswith(SERIES_PREFIX):
            parent = selection
            index = 'end'
        else:
            parent = ''
            index = 0
        if book is not None:
            try:
                bkId = self._collection.add_book(book, parent, index)
                self.isModified = True
            except RuntimeError as ex:
                self._set_status(f'!{str(ex)}')
            else:
                if bkId is not None:
                    self._set_status(
                        f'{_("Book added to the collection")}: '
                        f'"{book.novel.title}".'
                    )
                else:
                    self._set_status(
                        f'!{_("Book already exists")}: "{book.novel.title}".'
                    )

    def _add_series(self, event=None):
        self._apply_changes()
        try:
            selection = self._collection.tree.selection()[0]
        except:
            selection = ''
        title = _('New Series')
        index = 0
        if selection.startswith(SERIES_PREFIX):
            index = self._collection.tree.index(selection) + 1
        try:
            self._collection.add_series(title, index)
            self.isModified = True
        except RuntimeError as ex:
            self._set_status(str(ex))

    def _apply_changes(self, event=None):
        try:
            title = self._indexCard.title.get()
            if title or self.element.title:
                if self.element.title != title:
                    self.element.title = title.strip()
                    self._collection.tree.item(
                        self.nodeId,
                        text=self.element.title,
                    )
                    self.isModified = True
            if self._indexCard.bodyBox.hasChanged:
                self.element.desc = self._indexCard.bodyBox.get_text()
                self.isModified = True
        except AttributeError:
            pass

    def _close_collection(self, event=None):
        if self.isModified and self._ui.ask_yes_no(
            message=_('Save changes?'),
            detail=_('There are unsaved changes'),
            title=FEATURE,
            parent=self,
        ):
            self._save_collection()
        self._apply_changes()
        self._indexCard.title.set('')
        self._indexCard.bodyBox.clear()
        self._collection.reset_tree()
        self._collection = None
        self.title('')
        self._show_status('')
        self._show_path('')
        self._fileMenu.entryconfig(_('Save'), state='disabled')
        self._fileMenu.entryconfig(_('Close'), state='disabled')
        self.lift()
        self.focus()

    def _create_new_collection(self, event=None):
        self._apply_changes()
        fileTypes = [
            (_('novelibre collection'), Collection.EXTENSION),
        ]
        fileName = filedialog.asksaveasfilename(
            filetypes=fileTypes,
            defaultextension=fileTypes[0][1],
        )
        self.lift()
        self.focus()
        if not fileName:
            return False

        if self._collection is not None:
            self._close_collection()

        self._collection = Collection(fileName, self._treeView)
        self.prefs['last_open'] = fileName
        self._show_path(f'{norm_path(self._collection.filePath)}')
        self._set_title()
        self._fileMenu.entryconfig(_('Save'), state='normal')
        self._fileMenu.entryconfig(_('Close'), state='normal')
        return True

    def _move_node(self, event):
        tv = event.widget
        node = tv.selection()[0]
        targetNode = tv.identify_row(event.y)
        if node == targetNode:
            return

        if node[:2] == targetNode[:2]:
            tv.move(node, tv.parent(targetNode), tv.index(targetNode))
            self.isModified = True
        elif (node.startswith(BOOK_PREFIX)
              and targetNode.startswith(SERIES_PREFIX)
        ):
            if tv.get_children(targetNode):
                tv.move(node, tv.parent(targetNode), tv.index(targetNode))
            else:
                tv.move(node, targetNode, 0)
            self.isModified = True

    def _on_select_node(self, event=None):
        self._apply_changes()
        try:
            self.nodeId = self._collection.tree.selection()[0]
            if self.nodeId.startswith(BOOK_PREFIX):
                self.element = self._collection.books[self.nodeId]
            elif self.nodeId.startswith(SERIES_PREFIX):
                self.element = self._collection.series[self.nodeId]
        except IndexError:
            pass
        except AttributeError:
            pass
        else:
            self._set_element_view()

    def _open_book(self, event=None):
        self._apply_changes()
        try:
            nodeId = self._collection.tree.selection()[0]
            if nodeId.startswith(BOOK_PREFIX):
                self._ctrl.open_project(
                    filePath=self._collection.books[nodeId].filePath,
                )
        except IndexError:
            pass
        self.focus_set()

    def _open_collection(self, fileName='', event=None):
        self._apply_changes()
        self._show_status(self.statusText)
        fileName = self._select_collection(fileName)
        self.lift()
        self.focus()
        if not fileName:
            return False

        if self._collection is not None:
            self._close_collection()

        self.isModified = False
        self.prefs['last_open'] = fileName
        self._collection = Collection(fileName, self._treeView)
        try:
            self._collection.read()
        except RuntimeError as ex:
            self._close_collection()
            self._set_status(f'!{str(ex)}')
            return False

        self._show_path(f'{norm_path(self._collection.filePath)}')
        self._set_title()
        self._fileMenu.entryconfig(_('Save'), state='normal')
        self._fileMenu.entryconfig(_('Close'), state='normal')
        return True

    def _open_help(self, event=None):
        self._apply_changes()
        self._ctrl.helpService.open_help_page(HELP_PAGE)

    def _open_last_collection(self):
        if self._open_collection(fileName=self.prefs['last_open']):
            self.isOpen = True

    def _remove_book(self, event=None):
        self._apply_changes()
        try:
            nodeId = self._collection.tree.selection()[0]
        except IndexError:
            return

        try:
            if nodeId.startswith(BOOK_PREFIX):
                if self._ui.ask_yes_no(
                    message=_('Remove selected book from the collection?'),
                    detail=self._collection.books[nodeId].title,
                    title=FEATURE,
                    parent=self,
                ):
                    if self._collection.tree.prev(nodeId):
                        self._collection.tree.selection_set(
                            self._collection.tree.prev(nodeId)
                        )
                    elif self._collection.tree.parent(nodeId):
                        self._collection.tree.selection_set(
                            self._collection.tree.parent(nodeId)
                        )
                    self._set_status(self._collection.remove_book(nodeId))
                    self.isModified = True
        except RuntimeError as ex:
            self._set_status(str(ex))

    def _remove_node(self, event=None):
        self._apply_changes()
        try:
            nodeId = self._collection.tree.selection()[0]
            if nodeId.startswith(SERIES_PREFIX):
                self._remove_series()
            elif nodeId.startswith(BOOK_PREFIX):
                self._remove_book()
        except IndexError:
            pass

    def _remove_series(self, event=None):
        self._apply_changes()
        try:
            nodeId = self._collection.tree.selection()[0]

        except IndexError:
            return

        try:
            if nodeId.startswith(SERIES_PREFIX):
                if self._ui.ask_yes_no(
                    message=_('Remove selected series but keep the books?'),
                    detail=self._collection.series[nodeId].title,
                    title=FEATURE,
                    parent=self,
                ):
                    if self._collection.tree.prev(nodeId):
                        self._collection.tree.selection_set(
                            self._collection.tree.prev(nodeId)
                        )
                    elif self._collection.tree.parent(nodeId):
                        self._collection.tree.selection_set(
                            self._collection.tree.parent(nodeId)
                        )
                    self._set_status(self._collection.remove_series(nodeId))
                    self.isModified = True
        except RuntimeError as ex:
            self._set_status(str(ex))

    def _remove_series_with_books(self, event=None):
        self._apply_changes()
        try:
            nodeId = self._collection.tree.selection()[0]
        except IndexError:
            return

        try:
            if nodeId.startswith(SERIES_PREFIX):
                if self._ui.ask_yes_no(
                    message=_('Remove selected series and books?'),
                    detail=self._collection.series[nodeId].title,
                    title=FEATURE,
                    parent=self,
                ):
                    if self._collection.tree.prev(nodeId):
                        self._collection.tree.selection_set(
                            self._collection.tree.prev(nodeId)
                        )
                    elif self._collection.tree.parent(nodeId):
                        self._collection.tree.selection_set(
                            self._collection.tree.parent(nodeId)
                        )
                    self._set_status(
                        self._collection.remove_series_with_books(nodeId)
                    )
                    self.isModified = True
        except RuntimeError as ex:
            self._set_status(str(ex))

    def _restore_status(self, event=None):
        self._show_status(self.statusText)

    def _save_collection(self, event=None):
        if self._collection is None:
            return

        if not self.isModified:
            self._set_status(f"{_('No changes to save')}.")
            return

        self._apply_changes()
        try:
            self._collection.write()
        except Exception as ex:
            self._show_cannot_save_error(str(ex))
        else:
            self.isModified = False
            self._set_status(f"{_('Collection saved')}.")

    def _select_collection(self, fileName):
        initDir = os.path.dirname(self.prefs['last_open'])
        if not initDir:
            initDir = './'
        if not fileName or not os.path.isfile(fileName):
            fileTypes = [
                (_('novelibre collection'), Collection.EXTENSION),
            ]
            fileName = filedialog.askopenfilename(
                filetypes=fileTypes,
                defaultextension=fileTypes[0][1],
                initialdir=initDir,
                parent=self,
            )
        if not fileName:
            return ''

        return fileName

    def _set_element_view(self, event=None):
        self._indexCard.bodyBox.clear()
        if self.element.desc:
            self._indexCard.bodyBox.set_text(self.element.desc)
        if self.element.title:
            self._indexCard.title.set(self.element.title)

    def _set_status(self, statusMsg):
        if statusMsg.startswith('!'):
            self._statusBar.config(bg='red')
            self._statusBar.config(fg='white')
            self.infoHowText = statusMsg.split('!', maxsplit=1)[1].strip()
        else:
            self._statusBar.config(bg='green')
            self._statusBar.config(fg='white')
            self.infoHowText = statusMsg
        self._statusBar.config(text=self.infoHowText)

    def _set_title(self):
        if self._collection.title:
            collectionTitle = self._collection.title
        else:
            collectionTitle = _('Untitled collection')
        self.title(f'{collectionTitle} - {FEATURE}')

    def _show_cannot_save_error(self, errorMsg):
        self._ui.show_error(
            message=_('Cannot save the collection'),
            detail=errorMsg,
            parent=self,
        )
        self.lift()
        self.focus()

    def _show_path(self, pathStr):
        self._pathBar.config(text=pathStr)

    def _show_status(self, statusMsg):
        self.statusText = statusMsg
        self._statusBar.config(bg=self.cget('background'))
        self._statusBar.config(fg='black')
        self._statusBar.config(text=statusMsg)

    def _update_collection(self, event=None):
        self._apply_changes()
        if self._mdl.novel is None:
            return

        if self.nodeId is None:
            return

        if (self._collection.books[self.nodeId].filePath
            != self._mdl.prjFile.filePath
        ):
            return

        self._ui.refresh()
        if self._collection.books[self.nodeId].pull_metadata(self._mdl.novel):
            self.isModified = True
            self._set_element_view()

    def _update_project(self, event=None):
        self._apply_changes()
        if self._mdl.novel is None:
            return

        if self.nodeId is None:
            return

        if (self._collection.books[self.nodeId].filePath
            != self._mdl.prjFile.filePath
        ):
            return

        self._apply_changes()
        self._collection.books[self.nodeId].push_metadata(self._mdl.novel)



class CollectionService(SubController):
    INI_FILENAME = 'collection.ini'
    INI_FILEPATH = '.novx/config'
    SETTINGS = dict(
        last_open='',
        window_geometry='600x300',
        right_frame_width=350,
    )
    OPTIONS = {}
    ICON = 'collection'

    def __init__(self, model, view, controller):
        self._mdl = model
        self._ui = view
        self._ctrl = controller

        try:
            homeDir = str(Path.home()).replace('\\', '/')
            configDir = f'{homeDir}/{self.INI_FILEPATH}'
        except:
            configDir = '.'
        self.configuration = self._mdl.nvService.new_configuration(
            settings=self.SETTINGS,
            options=self.OPTIONS,
            filePath=f'{configDir}/{self.INI_FILENAME}',
        )
        self.configuration.read()
        self.prefs = {}
        self.prefs.update(self.configuration.settings)
        self.prefs.update(self.configuration.options)
        globalPrefs = self._ctrl.get_preferences()
        self.prefs['color_text_fg'] = globalPrefs['color_text_fg']
        self.prefs['color_text_bg'] = globalPrefs['color_text_bg']

        try:
            path = os.path.dirname(sys.argv[0])
            if not path:
                path = '.'
            self.icon = tk.PhotoImage(file=f'{path}/icons/{self.ICON}.png')
        except:
            self.icon = None

        self.collectionView = None

    def on_quit(self):
        if self.collectionView:
            if self.collectionView.isOpen:
                self.collectionView.on_quit()

        for keyword in self.prefs:
            if keyword in self.configuration.options:
                self.configuration.options[keyword] = self.prefs[keyword]
            elif keyword in self.configuration.settings:
                self.configuration.settings[keyword] = self.prefs[keyword]
        self.configuration.write()

    def start_manager(self):
        if self.collectionView:
            if self.collectionView.isOpen:
                if self.collectionView.state() == 'iconic':
                    self.collectionView.state('normal')
                self.collectionView.lift()
                self.collectionView.focus()
                return

        self.collectionView = CollectionView(
            self._mdl,
            self._ui,
            self._ctrl,
            self.prefs,
        )
        if self.icon:
            self.collectionView.iconphoto(False, self.icon)



class Plugin(PluginBase):
    VERSION = '5.8.2'
    API_VERSION = '5.63'
    DESCRIPTION = 'A book/series collection manager'
    URL = 'https://github.com/peter88213/nv_collection'
    HELP_PAGE = HELP_PAGE

    def install(self, model, view, controller):
        """Install the plugin at runtime.
        
        Positional arguments:
            model -- reference to the novelibre main model instance.
            view -- reference to the novelibre main view instance.
            controller -- reference to the novelibre main controller instance.

        Extends the superclass method.
        """
        super().install(model, view, controller)
        self.collectionService = CollectionService(model, view, controller)
        self._icon = self._get_icon('collection.png')


        label = FEATURE
        self._ui.fileMenu.insert_command(
            0,
            label=label,
            image=self._icon,
            compound='left',
            command=self.collectionService.start_manager,
            state='normal',
        )
        self._ui.fileMenu.insert_separator(1)

        self._add_help_menu_entry(_('Collection plugin help'))

    def on_quit(self):
        self.collectionService.on_quit()

