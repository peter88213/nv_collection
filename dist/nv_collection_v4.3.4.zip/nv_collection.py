"""A project collection manager plugin for novelibre.

Requires Python 3.6+
Copyright (c) 2024 Peter Triesberger
For further information see https://github.com/peter88213/nv_collection
License: GNU GPLv3 (https://www.gnu.org/licenses/gpl-3.0.en.html)

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
"""
import os
from pathlib import Path
import sys

import gettext
import locale
import webbrowser


class Error(Exception):
    pass


LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
try:
    CURRENT_LANGUAGE = locale.getlocale()[0][:2]
except:
    CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
try:
    t = gettext.translation('nv_collection', LOCALE_PATH, languages=[CURRENT_LANGUAGE])
    _ = t.gettext
except:

    def _(message):
        return message

FEATURE = _('Collection')
SERIES_PREFIX = 'sr'
BOOK_PREFIX = 'bk'
HELP_URL = f'https://peter88213.github.io/{_("nvhelp-en")}/nv_collection/'


def norm_path(path):
    if path is None:
        path = ''
    return os.path.normpath(path)


def open_help(event=None):
    webbrowser.open(HELP_URL)
from tkinter import filedialog
from tkinter import messagebox
from tkinter import ttk

import tkinter as tk
from tkinter import ttk



class TextBox(tk.Text):

    def __init__(self, master=None, scrollbar=True, **kw):
        if kw.get('font', None) is None:
            kw['font'] = 'Courier 10'
        if scrollbar:
            self.frame = ttk.Frame(master)
            self.vbar = ttk.Scrollbar(self.frame)
            self.vbar.pack(side='right', fill='y')

            kw.update({'yscrollcommand': self.vbar.set})
            tk.Text.__init__(self, self.frame, **kw)
            self.pack(side='left', fill='both', expand=True)
            self.vbar['command'] = self.yview

            text_meths = vars(tk.Text).keys()
            methods = vars(tk.Pack).keys() | vars(tk.Grid).keys() | vars(tk.Place).keys()
            methods = methods.difference(text_meths)

            for m in methods:
                if m[0] != '_' and m != 'config' and m != 'configure':
                    setattr(self, m, getattr(self.frame, m))
        else:
            tk.Text.__init__(self, master, **kw)

        self.hasChanged = False
        self.bind('<KeyRelease>', self._on_edit)

    def clear(self):
        self.delete('1.0', 'end')
        self.hasChanged = False

    def get_text(self):
        text = self.get('1.0', 'end').strip(' \n')
        return text

    def set_text(self, text):
        self.clear()
        if text:
            self.insert('end', text)
            self.edit_reset()

    def _on_edit(self, event=None):
        self.hasChanged = True



class MyStringVar(tk.StringVar):

    def set(self, value):
        if value is None:
            value = ''
        super().set(value)

    def get(self):
        value = super().get()
        if value == '':
            value = None
        return value


class IndexCard(tk.Frame):

    def __init__(self, master=None, cnf={}, fg='black', bg='white', font=None, scrollbar=True, **kw):
        super().__init__(master=master, cnf=cnf, **kw)
        self.title = MyStringVar(value='')
        self.titleEntry = tk.Entry(
            self,
            bg=bg,
            bd=0,
            textvariable=self.title,
            relief='flat',
            font=font,
            )
        self.titleEntry.config({
            'background': bg,
            'foreground': fg,
            'insertbackground': fg,
            })
        self.titleEntry.pack(fill='x', ipady=6)

        tk.Frame(self, bg='red', height=1, bd=0).pack(fill='x')
        tk.Frame(self, bg=bg, height=1, bd=0).pack(fill='x')

        self.bodyBox = TextBox(
            self,
            scrollbar=scrollbar,
            wrap='word',
            undo=True,
            autoseparators=True,
            maxundo=-1,
            padx=5,
            pady=5,
            bg=bg,
            fg=fg,
            insertbackground=fg,
            font=font,
            )
        self.bodyBox.pack(fill='both', expand=True)

    def lock(self):
        self.titleEntry.config(state='disabled')
        self.bodyBox.config(state='disabled')

    def unlock(self):
        self.titleEntry.config(state='normal')
        self.bodyBox.config(state='normal')



def create_id(elements, prefix=''):
    i = 1
    while f'{prefix}{i}' in elements:
        i += 1
    return f'{prefix}{i}'

import re


def strip_illegal_characters(text):
    return re.sub('[\x00-\x08|\x0b-\x0c|\x0e-\x1f]', '', text)



def indent(elem, level=0):
    PARAGRAPH_LEVEL = 5

    i = f'\n{level * "  "}'
    if len(elem):
        if not elem.text or not elem.text.strip():
            elem.text = f'{i}  '
        if not elem.tail or not elem.tail.strip():
            elem.tail = i
        if level < PARAGRAPH_LEVEL:
            for elem in elem:
                indent(elem, level + 1)
        if not elem.tail or not elem.tail.strip():
            elem.tail = i
    else:
        if level and (not elem.tail or not elem.tail.strip()):
            elem.tail = i
from calendar import day_name
from calendar import month_name
from datetime import date
from datetime import time

ROOT_PREFIX = 'rt'
CHAPTER_PREFIX = 'ch'
PLOT_LINE_PREFIX = 'ac'
SECTION_PREFIX = 'sc'
PLOT_POINT_PREFIX = 'ap'
CHARACTER_PREFIX = 'cr'
LOCATION_PREFIX = 'lc'
ITEM_PREFIX = 'it'
PRJ_NOTE_PREFIX = 'pn'
CH_ROOT = f'{ROOT_PREFIX}{CHAPTER_PREFIX}'
PL_ROOT = f'{ROOT_PREFIX}{PLOT_LINE_PREFIX}'
CR_ROOT = f'{ROOT_PREFIX}{CHARACTER_PREFIX}'
LC_ROOT = f'{ROOT_PREFIX}{LOCATION_PREFIX}'
IT_ROOT = f'{ROOT_PREFIX}{ITEM_PREFIX}'
PN_ROOT = f'{ROOT_PREFIX}{PRJ_NOTE_PREFIX}'

BRF_SYNOPSIS_SUFFIX = '_brf_synopsis'
CHAPTERS_SUFFIX = '_chapters_tmp'
CHARACTER_REPORT_SUFFIX = '_character_report'
CHARACTERS_SUFFIX = '_characters_tmp'
CHARLIST_SUFFIX = '_charlist_tmp'
DATA_SUFFIX = '_data'
GRID_SUFFIX = '_grid_tmp'
ITEM_REPORT_SUFFIX = '_item_report'
ITEMLIST_SUFFIX = '_itemlist_tmp'
ITEMS_SUFFIX = '_items_tmp'
LOCATION_REPORT_SUFFIX = '_location_report'
LOCATIONS_SUFFIX = '_locations_tmp'
LOCLIST_SUFFIX = '_loclist_tmp'
MANUSCRIPT_SUFFIX = '_manuscript_tmp'
PARTS_SUFFIX = '_parts_tmp'
PLOTLIST_SUFFIX = '_plotlist'
PLOTLINES_SUFFIX = '_plotlines_tmp'
PROJECTNOTES_SUFFIX = '_projectnote_report'
PROOF_SUFFIX = '_proof_tmp'
SECTIONLIST_SUFFIX = '_sectionlist'
SECTIONS_SUFFIX = '_sections_tmp'
STAGES_SUFFIX = '_structure_tmp'
XREF_SUFFIX = '_xref'


class Error(Exception):
    pass


class Notification(Error):
    pass


try:
    LOCALE_PATH
except NameError:
    locale.setlocale(locale.LC_TIME, "")
    LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
    try:
        CURRENT_LANGUAGE = locale.getlocale()[0][:2]
    except:
        CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
    try:
        t = gettext.translation('novelibre', LOCALE_PATH, languages=[CURRENT_LANGUAGE])
        _ = t.gettext
    except:

        def _(message):
            return message

WEEKDAYS = day_name
MONTHS = month_name


def norm_path(path):
    if path is None:
        path = ''
    return os.path.normpath(path)


def string_to_list(text, divider=';'):
    elements = []
    try:
        tempList = text.split(divider)
        for element in tempList:
            element = element.strip()
            if element and not element in elements:
                elements.append(element)
        return elements

    except:
        return []


def list_to_string(elements, divider=';'):
    try:
        text = divider.join(elements)
        return text

    except:
        return ''


def intersection(elemList, refList):
    return [elem for elem in elemList if elem in refList]


def verified_date(dateStr):
    if dateStr is not None:
        date.fromisoformat(dateStr)
    return dateStr


def verified_int_string(intStr):
    if intStr is not None:
        int(intStr)
    return intStr


def verified_time(timeStr):
    if  timeStr is not None:
        time.fromisoformat(timeStr)
        while timeStr.count(':') < 2:
            timeStr = f'{timeStr}:00'
    return timeStr

import xml.etree.ElementTree as ET


def get_xml_root(filePath):
    try:
        xmlTree = ET.parse(filePath)
    except Exception as ex:
        raise Error(f'{_("Cannot process file")}: "{norm_path(filePath)}" - {str(ex)}')

    return xmlTree.getroot()


class Book:

    def __init__(self, filePath):
        self.filePath = filePath
        self.title = None
        self.desc = None

    def pull_metadata(self, novel):
        modified = False
        if self.title != novel.title:
            self.title = novel.title
            modified = True
        if self.desc != novel.desc:
            self.desc = novel.desc
            modified = True
        return modified

    def push_metadata(self, novel):
        novel.title = self.title
        novel.desc = self.desc



class Series:

    def __init__(self):
        self.title = None
        self.desc = None
import tkinter.font as tkFont


class Collection:
    MAJOR_VERSION = 1
    MINOR_VERSION = 0

    XML_HEADER = '''<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE COLLECTION SYSTEM "nvcx_1_0.dtd">
<?xml-stylesheet href="collection.css" type="text/css"?>
'''

    EXTENSION = 'nvcx'

    def __init__(self, filePath, tree):
        self.title = None
        self.tree = tree
        fontSize = tkFont.nametofont('TkDefaultFont').actual()['size']
        self.tree.tag_configure('SERIES', font=('', fontSize, 'bold'))

        self.books = {}

        self.series = {}

        self._filePath = None

        self.filePath = filePath

    @property
    def filePath(self):
        return self._filePath

    @filePath.setter
    def filePath(self, filePath):
        if filePath.lower().endswith(self.EXTENSION):
            self._filePath = filePath
            self.title, __ = os.path.splitext(os.path.basename(self.filePath))

    def read(self):

        def get_book(parent, xmlBook):
            bkId = xmlBook.attrib[('id')]
            xmlPath = xmlBook.find('Path')
            if xmlPath is not None:
                bookPath = xmlPath.text
                if bookPath and os.path.isfile(bookPath):
                    self.books[bkId] = Book(bookPath)
                    xmlTitle = xmlBook.find('Title')
                    if xmlTitle is not None and xmlTitle.text:
                        self.books[bkId].title = xmlTitle.text
                    else:
                        self.books[bkId].title = f"{_('Untitled')} ({bkId})"
                    xmlDesc = xmlBook.find('Desc')
                    if xmlDesc is not None:
                        paragraphs = []
                        for xmlParagraph in xmlDesc.iterfind('p'):
                            if xmlParagraph.text:
                                paragraphs.append(xmlParagraph.text)
                        self.books[bkId].desc = '\n'.join(paragraphs)
                    self.tree.insert(parent, 'end', bkId, text=self.books[bkId].title, open=True)

        xmlRoot = get_xml_root(self.filePath)
        if not xmlRoot.tag == 'COLLECTION':
            raise Error(f'{_("No collection found in file")}: "{norm_path(self.filePath)}".')

        try:
            majorVersionStr, minorVersionStr = xmlRoot.attrib['version'].split('.')
            majorVersion = int(majorVersionStr)
            minorVersion = int(minorVersionStr)
        except:
            raise Error(f'{_("No valid version found in file")}: "{norm_path(self.filePath)}".')

        if majorVersion > self.MAJOR_VERSION:
            raise Error(_('The collection was created with a newer plugin version.'))

        elif majorVersion < self.MAJOR_VERSION:
            raise Error(_('The collection was created with an outdated plugin version.'))

        elif minorVersion > self.MINOR_VERSION:
            raise Error(_('The collection was created with a newer plugin version.'))

        self.reset_tree()
        self.books = {}
        self.series = {}
        for xmlElement in xmlRoot:
            if xmlElement.tag == 'BOOK':
                get_book('', xmlElement)
            elif xmlElement.tag == 'SERIES':
                srId = xmlElement.attrib['id']
                self.series[srId] = Series()
                xmlTitle = xmlElement.find('Title')
                if xmlTitle is not None and xmlTitle.text:
                    self.series[srId].title = xmlTitle.text
                else:
                    self.series[srId].title = f"{_('Untitled')} ({srId})"
                xmlDesc = xmlElement.find('Desc')
                if xmlDesc is not None:
                    paragraphs = []
                    for xmlParagraph in xmlDesc.iterfind('p'):
                        if xmlParagraph.text:
                            paragraphs.append(xmlParagraph.text)
                    self.series[srId].desc = '\n'.join(paragraphs)
                self.tree.insert('', 'end', srId, text=self.series[srId].title, tags='SERIES', open=True)
                for xmlBook in xmlElement.iter('BOOK'):
                    get_book(srId, xmlBook)
        if not xmlRoot.attrib.get('version', None):
            self.write()
        return f'{len(self.books)} Books found in "{norm_path(self.filePath)}".'

    def write(self):

        def walk_tree(node, xmlNode):
            for elementId in self.tree.get_children(node):
                if elementId.startswith(BOOK_PREFIX):
                    xmlBook = ET.SubElement(xmlNode, 'BOOK')
                    xmlBook.set('id', elementId)
                    xmlBookTitle = ET.SubElement(xmlBook, 'Title')
                    if self.books[elementId].title:
                        xmlBookTitle.text = self.books[elementId].title
                    if self.books[elementId].desc:
                        xmlBookDesc = ET.SubElement(xmlBook, 'Desc')
                        for paragraph in self.books[elementId].desc.split('\n'):
                            ET.SubElement(xmlBookDesc, 'p').text = paragraph.strip()
                    xmlBookPath = ET.SubElement(xmlBook, 'Path')
                    xmlBookPath.text = self.books[elementId].filePath
                elif elementId.startswith(SERIES_PREFIX):
                    xmlSeries = ET.SubElement(xmlNode, 'SERIES')
                    xmlSeries.set('id', elementId)
                    xmlSeriesTitle = ET.SubElement(xmlSeries, 'Title')
                    if self.series[elementId].title:
                        xmlSeriesTitle.text = self.series[elementId].title
                    if self.series[elementId].desc:
                        xmlSeriesDesc = ET.SubElement(xmlSeries, 'Desc')
                        for paragraph in self.series[elementId].desc.split('\n'):
                            ET.SubElement(xmlSeriesDesc, 'p').text = paragraph.strip()
                    walk_tree(elementId, xmlSeries)

        xmlRoot = ET.Element('COLLECTION')
        xmlRoot.set('version', f'{self.MAJOR_VERSION}.{self.MINOR_VERSION}')
        walk_tree('', xmlRoot)

        indent(xmlRoot)
        xmlTree = ET.ElementTree(xmlRoot)
        backedUp = False
        if os.path.isfile(self.filePath):
            try:
                os.replace(self.filePath, f'{self.filePath}.bak')
            except:
                raise Error(f'{_("Cannot overwrite file")}: "{norm_path(self.filePath)}".')
            else:
                backedUp = True
        try:
            xmlTree.write(self.filePath, encoding='utf-8')

            self._postprocess_xml_file(self.filePath)
        except:
            if backedUp:
                os.replace(f'{self.filePath}.bak', self.filePath)
            raise Error(f'{_("Cannot write file")}: "{norm_path(self.filePath)}".')

        return f'"{norm_path(self.filePath)}" written.'

    def add_book(self, book, parent='', index='end'):
        if book.filePath is None:
            raise Error(_('There is no file for the current project. Please save first.'))

        if not os.path.isfile(book.filePath):
            raise Error(f'"{norm_path(book.filePath)}" not found.')

        for bkId in self.books:
            if book.filePath == self.books[bkId].filePath:
                return None

        bkId = create_id(self.books, prefix=BOOK_PREFIX)
        self.books[bkId] = Book(book.filePath)
        self.books[bkId].pull_metadata(book.novel)
        self.tree.insert(parent, index, bkId, text=self.books[bkId].title, open=True)
        return bkId

    def remove_book(self, bkId):
        bookTitle = bkId
        try:
            bookTitle = self.books[bkId].title
            del self.books[bkId]
            self.tree.delete(bkId)
            message = f'{_("Book removed from the collection")}: "{bookTitle}".'
            return message
        except:
            raise Error(f'{_("Cannot remove book")}: "{bookTitle}".')

    def add_series(self, seriesTitle, index='end'):
        srId = create_id(self.series, prefix=SERIES_PREFIX)
        self.series[srId] = Series()
        self.series[srId].title = seriesTitle
        self.tree.insert('', index, srId, text=self.series[srId].title, tags='SERIES', open=True)

    def remove_series(self, srId):
        seriesTitle = self.series[srId].title
        for bookNode in self.tree.get_children(srId):
            self.tree.move(bookNode, '', 'end')
        del(self.series[srId])
        self.tree.delete(srId)
        return f'"{seriesTitle}" series removed from the collection.'

        raise Error(f'{_("Cannot remove series")}: "{seriesTitle}".')

    def remove_series_with_books(self, srId):
        seriesTitle = self.series[srId].title
        for bkId in self.tree.get_children(srId):
            del self.books[bkId]
        del(self.series[srId])
        self.tree.delete(srId)
        return f'"{seriesTitle}" series removed from the collection.'

        raise Error(f'{_("Cannot remove series")}: "{seriesTitle}".')

    def _postprocess_xml_file(self, filePath):
        with open(filePath, 'r', encoding='utf-8') as f:
            text = f.read()
            text = strip_illegal_characters(text)
        try:
            with open(filePath, 'w', encoding='utf-8') as f:
                f.write(f'{self.XML_HEADER}{text}')
        except:
            raise Error(f'{_("Cannot write file")}: "{norm_path(filePath)}".')

    def reset_tree(self):
        for child in self.tree.get_children(''):
            self.tree.delete(child)

from configparser import ConfigParser


class Configuration:

    def __init__(self, settings={}, options={}):
        self.settings = None
        self.options = None
        self._sLabel = 'SETTINGS'
        self._oLabel = 'OPTIONS'
        self.set(settings, options)

    def set(self, settings=None, options=None):
        if settings is not None:
            self.settings = settings.copy()
        if options is not None:
            self.options = options.copy()

    def read(self, iniFile):
        config = ConfigParser()
        config.read(iniFile, encoding='utf-8')
        if config.has_section(self._sLabel):
            section = config[self._sLabel]
            for setting in self.settings:
                fallback = self.settings[setting]
                self.settings[setting] = section.get(setting, fallback)
        if config.has_section(self._oLabel):
            section = config[self._oLabel]
            for option in self.options:
                fallback = self.options[option]
                self.options[option] = section.getboolean(option, fallback)

    def write(self, iniFile):
        config = ConfigParser()
        if self.settings:
            config.add_section(self._sLabel)
            for settingId in self.settings:
                config.set(self._sLabel, settingId, str(self.settings[settingId]))
        if self.options:
            config.add_section(self._oLabel)
            for settingId in self.options:
                if self.options[settingId]:
                    config.set(self._oLabel, settingId, 'Yes')
                else:
                    config.set(self._oLabel, settingId, 'No')
        with open(iniFile, 'w', encoding='utf-8') as f:
            config.write(f)
import platform



class GenericKeys:

    OPEN_HELP = ('<F1>', 'F1')
    QUIT_PROGRAM = ('<Control-q>', f'{_("Ctrl")}-Q')



class GenericMouse:

    LEFT_CLICK = '<Button-1>'
    MOVE_NODE = '<Alt-B1-Motion>'


class MacKeys(GenericKeys):

    QUIT_PROGRAM = ('<Command-q>', 'Cmd-Q')


class WindowsKeys(GenericKeys):

    QUIT_PROGRAM = ('<Alt-F4>', 'Alt-F4')

if platform.system() == 'Windows':
    PLATFORM = 'win'
    KEYS = WindowsKeys()
    MOUSE = GenericMouse
elif platform.system() in ('Linux', 'FreeBSD'):
    PLATFORM = 'ix'
    KEYS = GenericKeys()
    MOUSE = GenericMouse
elif platform.system() == 'Darwin':
    PLATFORM = 'mac'
    KEYS = MacKeys()
    MOUSE = GenericMouse
else:
    PLATFORM = ''
    KEYS = GenericKeys()
    MOUSE = GenericMouse



class CollectionManager(tk.Toplevel):

    INI_FILENAME = 'collection.ini'
    SETTINGS = dict(
        last_open='',
        tree_width='300',
    )
    OPTIONS = {}

    def __init__(self, model, view, controller, position, configDir):
        self._mdl = model
        self._ui = view
        self._ctrl = controller
        super().__init__()

        self.iniFile = f'{configDir}/{self.INI_FILENAME}'
        self.configuration = Configuration(self.SETTINGS, self.OPTIONS)
        self.configuration.read(self.iniFile)
        self.kwargs = {}
        self.kwargs.update(self.configuration.settings)

        self.title(FEATURE)
        self._statusText = ''

        self.geometry(position)
        self.lift()
        self.focus()

        self.protocol("WM_DELETE_WINDOW", self.on_quit)
        if PLATFORM != 'win':
            self.bind(KEYS.QUIT_PROGRAM[0], self.on_quit)

        self.mainMenu = tk.Menu(self)
        self.config(menu=self.mainMenu)

        self.mainWindow = ttk.Frame(self)
        self.mainWindow.pack(fill='both', padx=2, pady=2, expand=True)

        self.treeWindow = ttk.Panedwindow(self.mainWindow, orient='horizontal')
        self.treeWindow.pack(fill='both', expand=True)

        self.collection = None
        self._fileTypes = [(_('novelibre collection'), Collection.EXTENSION)]

        self.treeView = ttk.Treeview(self.treeWindow, selectmode='browse')
        scrollY = ttk.Scrollbar(self.treeView, orient='vertical', command=self.treeView.yview)
        self.treeView.configure(yscrollcommand=scrollY.set)
        scrollY.pack(side='right', fill='y')
        self.treeView.pack(side='left')
        self.treeWindow.add(self.treeView)
        self.treeView.bind('<<TreeviewSelect>>', self._on_select_node)
        self.treeView.bind('<<TreeviewSelect>>', self._on_select_node)
        self.treeView.bind('<Double-1>', self._open_book)
        self.treeView.bind('<Return>', self._open_book)
        self.treeView.bind('<Delete>', self._remove_node)
        self.treeView.bind('<Shift-Delete>', self._remove_series_with_books)
        self.treeView.bind(MOUSE.MOVE_NODE, self._move_node)

        self.indexCard = IndexCard(self.treeWindow, bd=2, relief='ridge')
        self.indexCard.pack(side='right')
        self.treeWindow.add(self.indexCard)

        self.treeWindow.update()
        self.treeWindow.sashpos(0, self.kwargs['tree_width'])

        self.statusBar = tk.Label(self, text='', anchor='w', padx=5, pady=2)
        self.statusBar.pack(expand=False, fill='both')
        self.statusBar.bind(MOUSE.LEFT_CLICK, self._restore_status)

        self.pathBar = tk.Label(self, text='', anchor='w', padx=5, pady=3)
        self.pathBar.pack(expand=False, fill='both')

        self.fileMenu = tk.Menu(self.mainMenu, tearoff=0)
        self.mainMenu.add_cascade(label=_('File'), menu=self.fileMenu)
        self.fileMenu.add_command(label=_('New'), command=self._new_collection)
        self.fileMenu.add_command(label=_('Open...'), command=lambda: self._open_collection(''))
        self.fileMenu.add_command(label=_('Save'), state='disabled', command=self._save_collection)
        self.fileMenu.add_command(label=_('Close'), state='disabled', command=self._close_collection)
        if PLATFORM == 'win':
            self.fileMenu.add_command(label=_('Exit'), accelerator=KEYS.QUIT_PROGRAM[1], command=self.on_quit)
        else:
            self.fileMenu.add_command(label=_('Quit'), accelerator=KEYS.QUIT_PROGRAM[1], command=self.on_quit)

        self.seriesMenu = tk.Menu(self.mainMenu, tearoff=0)
        self.mainMenu.add_cascade(label=_('Series'), menu=self.seriesMenu)
        self.seriesMenu.add_command(label=_('Add'), command=self._add_series)
        self.seriesMenu.add_command(label=_('Remove selected series but keep the books'), command=self._remove_series)
        self.seriesMenu.add_command(label=_('Remove selected series and books'), command=self._remove_series_with_books)

        self.bookMenu = tk.Menu(self.mainMenu, tearoff=0)
        self.mainMenu.add_cascade(label=_('Book'), menu=self.bookMenu)
        self.bookMenu.add_command(label=_('Add current project to the collection'), command=self._add_current_project)
        self.bookMenu.add_command(label=_('Remove selected book from the collection'), command=self._remove_book)
        self.bookMenu.add_command(label=_('Update book data from the current project'), command=self._update_collection)
        self.bookMenu.add_command(label=_('Update project data from the selected book'), command=self._update_project)

        self.helpMenu = tk.Menu(self.mainMenu, tearoff=0)
        self.mainMenu.add_cascade(label=_('Help'), menu=self.helpMenu)
        self.helpMenu.add_command(label=_('Online help'), accelerator='F1', command=open_help)

        self.bind(KEYS.OPEN_HELP[0], open_help)
        self.bind('<Escape>', self._restore_status)

        self.isModified = False
        self._element = None
        self._nodeId = None
        if self._open_collection(self.kwargs['last_open']):
            self.isOpen = True


    def on_quit(self, event=None):
        self._get_element_view()
        self.kwargs['tree_width'] = self.treeWindow.sashpos(0)

        for keyword in self.kwargs:
            if keyword in self.configuration.options:
                self.configuration.options[keyword] = self.kwargs[keyword]
            elif keyword in self.configuration.settings:
                self.configuration.settings[keyword] = self.kwargs[keyword]
        self.configuration.write(self.iniFile)
        try:
            if self.collection is not None:
                if self.isModified:
                    self.collection.write()
        except Exception as ex:
            self._show_info(str(ex))
        finally:
            self.destroy()
            self.isOpen = False

    def _on_select_node(self, event=None):
        self._get_element_view()
        try:
            self._nodeId = self.collection.tree.selection()[0]
            if self._nodeId.startswith(BOOK_PREFIX):
                self._element = self.collection.books[self._nodeId]
            elif self._nodeId.startswith(SERIES_PREFIX):
                self._element = self.collection.series[self._nodeId]
        except IndexError:
            pass
        except AttributeError:
            pass
        else:
            self._set_element_view()

    def _set_element_view(self, event=None):
        self.indexCard.bodyBox.clear()
        if self._element.desc:
            self.indexCard.bodyBox.set_text(self._element.desc)
        if self._element.title:
            self.indexCard.title.set(self._element.title)

    def _get_element_view(self, event=None):
        try:
            title = self.indexCard.title.get()
            if title or self._element.title:
                if self._element.title != title:
                    self._element.title = title.strip()
                    self.collection.tree.item(self._nodeId, text=self._element.title)
                    self.isModified = True
            if self.indexCard.bodyBox.hasChanged:
                self._element.desc = self.indexCard.bodyBox.get_text()
                self.isModified = True
        except AttributeError:
            pass

    def _show_info(self, message):
        if message.startswith('!'):
            message = message.split('!', maxsplit=1)[1].strip()
            messagebox.showerror(FEATURE, message=message, parent=self)
        else:
            messagebox.showinfo(FEATURE, message=message, parent=self)
        self.lift()
        self.focus()

    def _set_status(self, message):
        if message.startswith('!'):
            self.statusBar.config(bg='red')
            self.statusBar.config(fg='white')
            self.infoHowText = message.split('!', maxsplit=1)[1].strip()
        else:
            self.statusBar.config(bg='green')
            self.statusBar.config(fg='white')
            self.infoHowText = message
        self.statusBar.config(text=self.infoHowText)

    def _show_path(self, message):
        self.pathBar.config(text=message)

    def _show_status(self, message):
        self._statusText = message
        self.statusBar.config(bg=self.cget('background'))
        self.statusBar.config(fg='black')
        self.statusBar.config(text=message)

    def _restore_status(self, event=None):
        self._show_status(self._statusText)

    def _move_node(self, event):
        tv = event.widget
        node = tv.selection()[0]
        targetNode = tv.identify_row(event.y)
        if node[:2] == targetNode[:2]:
            tv.move(node, tv.parent(targetNode), tv.index(targetNode))
            self.isModified = True
        elif node.startswith(BOOK_PREFIX) and targetNode.startswith(SERIES_PREFIX):
            if tv.get_children(targetNode):
                tv.move(node, tv.parent(targetNode), tv.index(targetNode))
            else:
                tv.move(node, targetNode, 0)
            self.isModified = True


    def _open_book(self, event=None):
        try:
            nodeId = self.collection.tree.selection()[0]
            if nodeId.startswith(BOOK_PREFIX):
                self._ctrl.open_project(filePath=self.collection.books[nodeId].filePath)
        except IndexError:
            pass
        self.focus_set()

    def _add_current_project(self, event=None):
        try:
            selection = self.collection.tree.selection()[0]
        except:
            selection = ''
        book = self._mdl.prjFile
        if not self._mdl.prjFile.novel.title:
            self._set_status(f'!{_("This project has no title")}.')
            return

        parent = ''
        if selection.startswith(BOOK_PREFIX):
            parent = self.collection.tree.parent(selection)
            index = self.collection.tree.index(selection) + 1
        elif selection.startswith(SERIES_PREFIX):
            parent = selection
            index = 'end'
        else:
            parent = ''
            index = 0
        if book is not None:
            try:
                bkId = self.collection.add_book(book, parent, index)
                self.isModified = True
            except Error as ex:
                self._set_status(f'!{str(ex)}')
            else:
                if bkId is not None:
                    self._set_status(f'{_("Book added to the collection")}: "{book.novel.title}".')
                else:
                    self._set_status(f'!{_("Book already exists")}: "{book.novel.title}".')

    def _update_collection(self, event=None):
        if self._mdl.novel is None:
            return

        if self._nodeId is None:
            return

        if self.collection.books[self._nodeId].filePath != self._mdl.prjFile.filePath:
            return

        self._ui.refresh()
        if self.collection.books[self._nodeId].pull_metadata(self._mdl.novel):
            self.isModified = True
            self._set_element_view()

    def _update_project(self, event=None):
        if self._mdl.novel is None:
            return

        if self._nodeId is None:
            return

        if self.collection.books[self._nodeId].filePath != self._mdl.prjFile.filePath:
            return

        self._get_element_view()
        self.collection.books[self._nodeId].push_metadata(self._mdl.novel)

    def _remove_book(self, event=None):
        try:
            nodeId = self.collection.tree.selection()[0]
            message = ''
            try:
                if nodeId.startswith(BOOK_PREFIX):
                    if messagebox.askyesno(FEATURE, message=f'{_("Remove selected book from the collection")}?', parent=self):
                        if self.collection.tree.prev(nodeId):
                            self.collection.tree.selection_set(self.collection.tree.prev(nodeId))
                        elif self.collection.tree.parent(nodeId):
                            self.collection.tree.selection_set(self.collection.tree.parent(nodeId))
                        message = self.collection.remove_book(nodeId)
                        self.isModified = True
                        self.lift()
                        self.focus()
            except Error as ex:
                self._set_status(str(ex))
            else:
                if message:
                    self._set_status(message)
        except IndexError:
            pass

    def _add_series(self, event=None):
        try:
            selection = self.collection.tree.selection()[0]
        except:
            selection = ''
        title = _('New Series')
        index = 0
        if selection.startswith(SERIES_PREFIX):
            index = self.collection.tree.index(selection) + 1
        try:
            self.collection.add_series(title, index)
            self.isModified = True
        except Error as ex:
            self._set_status(str(ex))

    def _remove_series(self, event=None):
        try:
            nodeId = self.collection.tree.selection()[0]
            message = ''
            try:
                if nodeId.startswith(SERIES_PREFIX):
                    if messagebox.askyesno(FEATURE, message=f'{_("Remove selected series but keep the books")}?', parent=self):
                        if self.collection.tree.prev(nodeId):
                            self.collection.tree.selection_set(self.collection.tree.prev(nodeId))
                        elif self.collection.tree.parent(nodeId):
                            self.collection.tree.selection_set(self.collection.tree.parent(nodeId))
                        message = self.collection.remove_series(nodeId)
                        self.isModified = True
                        self.lift()
                        self.focus()
            except Error as ex:
                self._set_status(str(ex))
            else:
                if message:
                    self._set_status(message)
        except IndexError:
            pass

    def _remove_series_with_books(self, event=None):
        try:
            nodeId = self.collection.tree.selection()[0]
            message = ''
            try:
                if nodeId.startswith(SERIES_PREFIX):
                    if messagebox.askyesno(FEATURE, message=f'{_("Remove selected series and books")}?', parent=self):
                        if self.collection.tree.prev(nodeId):
                            self.collection.tree.selection_set(self.collection.tree.prev(nodeId))
                        elif self.collection.tree.parent(nodeId):
                            self.collection.tree.selection_set(self.collection.tree.parent(nodeId))
                        message = self.collection.remove_series_with_books(nodeId)
                        self.isModified = True
                        self.lift()
                        self.focus()
            except Error as ex:
                self._set_status(str(ex))
            else:
                if message:
                    self._set_status(message)
        except IndexError:
            pass

    def _remove_node(self, event=None):
        try:
            nodeId = self.collection.tree.selection()[0]
            if nodeId.startswith(SERIES_PREFIX):
                self._remove_series()
            elif nodeId.startswith(BOOK_PREFIX):
                self._remove_book()
            self.isModified = True
        except IndexError:
            pass


    def _select_collection(self, fileName):
        initDir = os.path.dirname(self.kwargs['last_open'])
        if not initDir:
            initDir = './'
        if not fileName or not os.path.isfile(fileName):
            fileName = filedialog.askopenfilename(filetypes=self._fileTypes, defaultextension=self._fileTypes[0][1], initialdir=initDir, parent=self)
        if not fileName:
            return ''

        return fileName

    def _open_collection(self, fileName):
        self._show_status(self._statusText)
        fileName = self._select_collection(fileName)
        self.lift()
        self.focus()
        if not fileName:
            return False

        if self.collection is not None:
            self._close_collection()

        self.kwargs['last_open'] = fileName
        self.collection = Collection(fileName, self.treeView)
        try:
            self.collection.read()
        except Error as ex:
            self._close_collection()
            self._set_status(f'!{str(ex)}')
            return False

        self._show_path(f'{norm_path(self.collection.filePath)}')
        self._set_title()
        self.fileMenu.entryconfig(_('Save'), state='normal')
        self.fileMenu.entryconfig(_('Close'), state='normal')
        return True

    def _new_collection(self, event=None):
        fileName = filedialog.asksaveasfilename(filetypes=self._fileTypes, defaultextension=self._fileTypes[0][1])
        self.lift()
        self.focus()
        if not fileName:
            return False

        if self.collection is not None:
            self._close_collection()

        self.collection = Collection(fileName, self.treeView)
        self.kwargs['last_open'] = fileName
        self._show_path(f'{norm_path(self.collection.filePath)}')
        self._set_title()
        self.fileMenu.entryconfig(_('Save'), state='normal')
        self.fileMenu.entryconfig(_('Close'), state='normal')
        return True

    def _save_collection(self, event=None):
        try:
            if self.collection is not None:
                if self.isModified:
                    self.collection.write()
        except Exception as ex:
            self._show_info(str(ex))
            return

        self.isModified = False
        self._set_status(_('Collection saved.'))

    def _close_collection(self, event=None):
        if self.isModified and self._ui.ask_yes_no(_('Save changes?')):
            self._save_collection()
        self._get_element_view()
        self.indexCard.title.set('')
        self.indexCard.bodyBox.clear()
        self.collection.reset_tree()
        self.collection = None
        self.title('')
        self._show_status('')
        self._show_path('')
        self.fileMenu.entryconfig(_('Save'), state='disabled')
        self.fileMenu.entryconfig(_('Close'), state='disabled')
        self.lift()
        self.focus()

    def _set_title(self):
        if self.collection.title:
            collectionTitle = self.collection.title
        else:
            collectionTitle = _('Untitled collection')
        self.title(f'{collectionTitle} - {FEATURE}')

from abc import ABC, abstractmethod


class PluginBase(ABC):
    VERSION = ''
    API_VERSION = ''
    DESCRIPTION = ''
    URL = ''

    def __init__(self):
        self.filePath = None
        self.isActive = True
        self.isRejected = False

    @abstractmethod
    def install(self, model, view, controller, prefs=None):
        self._mdl = model
        self._ui = view
        self._ctrl = controller

    def disable_menu(self):
        pass

    def enable_menu(self):
        pass

    def lock(self):
        pass

    def on_close(self):
        pass

    def on_quit(self):
        pass

    def unlock(self):
        pass


class Plugin(PluginBase):
    VERSION = '4.3.4'
    API_VERSION = '4.3'
    DESCRIPTION = 'A book/series collection manager'
    URL = 'https://github.com/peter88213/nv_collection'
    ICON = 'cLogo32'

    INI_FILEPATH = '.novx/config'

    def install(self, model, view, controller, prefs=None):
        """Add a submenu to the 'File' menu.
        
        Positional arguments:
            model -- reference to the main model instance of the application.
            view -- reference to the main view instance of the application.
            controller -- reference to the main controller instance of the application.

        Optional arguments:
            prefs -- deprecated. Please use controller.get_preferences() instead.
        
        Overrides the superclass method.
        """
        self._mdl = model
        self._ui = view
        self._ctrl = controller
        self._collectionManager = None

        self._ui.fileMenu.insert_command(0, label=FEATURE, command=self._start_manager)
        self._ui.fileMenu.insert_separator(1)
        self._ui.fileMenu.entryconfig(FEATURE, state='normal')

        self._ui.helpMenu.add_command(label=_('Collection plugin Online help'), command=open_help)

        self.sectionEditors = {}
        try:
            path = os.path.dirname(sys.argv[0])
            if not path:
                path = '.'
            self._icon = tk.PhotoImage(file=f'{path}/icons/{self.ICON}.png')
        except:
            self._icon = None

    def on_quit(self):
        """Write back the configuration file.
        
        Overrides the superclass method.
        """
        if self._collectionManager:
            if self._collectionManager.isOpen:
                self._collectionManager.on_quit()

    def _start_manager(self):
        if self._collectionManager:
            if self._collectionManager.isOpen:
                if self._collectionManager.state() == 'iconic':
                    self._collectionManager.state('normal')
                self._collectionManager.lift()
                self._collectionManager.focus()
                return

        __, x, y = self._ui.root.geometry().split('+')
        offset = 300
        windowGeometry = f'+{int(x)+offset}+{int(y)+offset}'
        try:
            homeDir = str(Path.home()).replace('\\', '/')
            configDir = f'{homeDir}/{self.INI_FILEPATH}'
        except:
            configDir = '.'
        self._collectionManager = CollectionManager(self._mdl, self._ui, self._ctrl, windowGeometry, configDir)
        self._collectionManager.iconphoto(False, self._icon)

